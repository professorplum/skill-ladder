# Tips System

Continuous learning system with action-oriented tips for full-stack web development.

## Philosophy

**Action-Oriented:** Every tip tells you to "Use X to do Y" or "Try X to accomplish Y"  
**Skill-Leveled:** Beginner and intermediate tips you can enable independently  
**Context-Aware:** Project detection and git hooks show relevant tips automatically  
**Your Stack Only:** Focused on Java, JavaScript, HTML, CSS, C#, Python, React, Spring, Azure, Docker

## Structure

### Two Types of Tips

**1. Daily Tips (Configurable)**
- Shown at terminal session start
- Rotate daily based on day of year
- Enable/disable beginner and intermediate independently
- Default: `terminal-beginner` and `git-beginner`

**2. Context-Aware Tips (Always Active)**
- Project detection: cd into project → shows relevant tip
- Git hooks: after commits, checkouts, merges → shows workflow tips
- Cannot be disabled (they're context-specific to what you're doing)

### Categories with Levels

Each category has beginner and intermediate subcategories you toggle independently:

**Core Tools:**
- `terminal-beginner` / `terminal-intermediate`
- `git-beginner` / `git-intermediate`

**Languages:**
- `java-beginner` / `java-intermediate` (language only)
- `javascript-beginner` / `javascript-intermediate` (language only)
- `html-beginner` / `html-intermediate`
- `css-beginner` / `css-intermediate`
- `csharp-beginner` / `csharp-intermediate` (language only)
- `python-beginner` / `python-intermediate` (language only, for web apps)

**Frameworks:**
- `react-beginner` / `react-intermediate` (hooks, components, patterns)
- `spring-beginner` / `spring-intermediate` (annotations, Spring Boot)

**Cloud & Tools:**
- `azure-beginner` / `azure-intermediate`
- `docker-beginner` / `docker-intermediate`

## Usage

### Configure Categories

```fish
# See what's available
tip-config --list

# Start with beginners
tip-config --enable java-beginner spring-beginner react-beginner

# Add intermediate as you progress
tip-config --enable java-intermediate spring-intermediate

# Check what's active
tip-config --status

# Disable when you've mastered
tip-config --disable java-beginner spring-beginner
```

### When Tips Appear

**Session Start:**
```bash
# Opens terminal in ~/projects/spring-api

💡 Daily Dev Tip:
   Try 'tldr docker' to see practical examples instead of man pages

💡 Spring Tip:
   Use @RestController to create REST endpoints instead of @Controller + @ResponseBody
```

**Git Actions:**
```bash
git commit -m "Add JWT auth"

💡 Git Tip:
   Use conventional commits for clear history: feat:, fix:, docs:, refactor:
```

**Project Navigation:**
```bash
cd ~/projects/picky-react

💡 React Tip:
   Use useState() hook to add state: const [count, setCount] = useState(0)
```

## Directory Structure

```
~/dotfiles/tips/
├── show-tip.fish
├── tip-config.fish
├── check-project-tip.fish
├── cd.fish
├── enabled-categories.txt
├── terminal/
│   ├── beginner.txt
│   └── intermediate.txt
├── git/
│   ├── beginner.txt
│   ├── intermediate.txt
│   ├── commit.txt (context-aware)
│   ├── checkout.txt (context-aware)
│   └── merge.txt (context-aware)
├── java/
│   ├── beginner.txt
│   └── intermediate.txt
├── javascript/
│   ├── beginner.txt
│   └── intermediate.txt
├── html/
│   ├── beginner.txt
│   └── intermediate.txt
├── css/
│   ├── beginner.txt
│   └── intermediate.txt
├── csharp/
│   ├── beginner.txt
│   └── intermediate.txt
├── python/
│   ├── beginner.txt
│   └── intermediate.txt
├── react/
│   ├── beginner.txt
│   └── intermediate.txt
├── spring/
│   ├── beginner.txt
│   └── intermediate.txt
├── azure/
│   ├── beginner.txt
│   └── intermediate.txt
└── docker/
    ├── beginner.txt
    └── intermediate.txt
```

## Project Detection Logic

Context-aware tips trigger automatically based on files in directory:

- **Spring Boot**: `pom.xml`, `build.gradle`, `gradlew` → Spring tips
- **React**: `package.json` → React tips
- **Python**: `requirements.txt`, `setup.py`, `pyproject.toml` → Python tips
- **C#**: `*.csproj`, `*.sln` → C# tips
- **Docker**: `Dockerfile`, `docker-compose.yml` → Docker tips

## Progression Path

**Week 1:** Start with beginner categories for your current project
```fish
tip-config --enable git-beginner java-beginner spring-beginner docker-beginner
```

**Month 2:** Add intermediate as you master basics
```fish
tip-config --enable java-intermediate spring-intermediate
```

**Month 3:** Expand to full stack
```fish
tip-config --enable javascript-beginner react-beginner html-beginner css-beginner
```

**Month 6:** Full intermediate stack
```fish
tip-config --enable javascript-intermediate react-intermediate css-intermediate
```

## Adding Your Own Tips

Add lines to any `.txt` file:
```bash
echo "Use @Transactional for database operations" >> ~/dotfiles/tips/spring/intermediate.txt
```

Tips are selected deterministically by day of year - same tip all day for reinforcement.

## Disabling Tips

**Disable specific levels:**
```fish
tip-config --disable java-beginner  # Keep intermediate active
```

**Turn off all daily tips temporarily:**
```fish
# Rename functions directory
mv ~/dotfiles/tips ~/.dotfiles-tips-disabled
```

**Context-aware tips (project/git) are always active** - they're triggered by your actions.

