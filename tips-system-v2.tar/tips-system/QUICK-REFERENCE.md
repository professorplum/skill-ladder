# Tips System - Quick Reference

## Your Categories (Beginner/Intermediate)

### Core Tools
```fish
tip-config --enable terminal-beginner terminal-intermediate
tip-config --enable git-beginner git-intermediate
```

### Languages (Separate from Frameworks)
```fish
# Java language
tip-config --enable java-beginner java-intermediate

# JavaScript language  
tip-config --enable javascript-beginner javascript-intermediate

# Markup/Style
tip-config --enable html-beginner html-intermediate
tip-config --enable css-beginner css-intermediate

# C# language
tip-config --enable csharp-beginner csharp-intermediate

# Python language (web app focus)
tip-config --enable python-beginner python-intermediate
```

### Frameworks (Annotations, Patterns, etc.)
```fish
# React framework
tip-config --enable react-beginner react-intermediate

# Spring Boot framework
tip-config --enable spring-beginner spring-intermediate
```

### Cloud & Tools
```fish
# Azure (not AWS)
tip-config --enable azure-beginner azure-intermediate

# Docker (no K8s/Terraform yet)
tip-config --enable docker-beginner docker-intermediate
```

## Common Workflows

### Backend Developer Focus
```fish
tip-config --enable \
  terminal-beginner git-beginner \
  java-beginner spring-beginner \
  docker-beginner azure-beginner
```

### Frontend Developer Focus
```fish
tip-config --enable \
  terminal-beginner git-beginner \
  javascript-beginner react-beginner \
  html-beginner css-beginner
```

### Full-Stack Beginner
```fish
tip-config --enable \
  terminal-beginner git-beginner \
  java-beginner spring-beginner \
  javascript-beginner react-beginner \
  html-beginner css-beginner \
  docker-beginner
```

### Advancing to Intermediate
```fish
# Add intermediate, keep beginner
tip-config --enable java-intermediate spring-intermediate

# Or replace beginner with intermediate
tip-config --disable java-beginner spring-beginner
tip-config --enable java-intermediate spring-intermediate
```

## Management Commands

```fish
# See all available categories with descriptions
tip-config --list

# Check what's currently enabled
tip-config --status

# Disable categories you've mastered
tip-config --disable java-beginner spring-beginner
```

## Context-Aware Tips (Always Active)

These trigger automatically - you don't enable/disable them:

**Project Detection:**
- `cd` into Spring project → Spring tip
- `cd` into React project → React tip
- `cd` into Python project → Python tip
- `cd` into C# project → C# tip
- `cd` into Docker project → Docker tip

**Git Workflow:**
- `git commit` → Commit workflow tip
- `git checkout` → Branch management tip
- `git merge` → Merge strategy tip

## Tip Format

Every tip is action-oriented:
- ✅ "Use X to accomplish Y"
- ✅ "Try X for Y"
- ❌ Not: "X is a feature that..."
- ❌ Not: "You can do X"

## Daily Rotation

Tips rotate daily based on day of year:
- Same tip shows all day (reinforcement)
- Different tip tomorrow (variety)
- Cycles through all 20 tips in category

## File Locations

```
~/dotfiles/tips/
├── terminal/{beginner,intermediate}.txt
├── git/{beginner,intermediate,commit,checkout,merge}.txt
├── java/{beginner,intermediate}.txt
├── javascript/{beginner,intermediate}.txt
├── html/{beginner,intermediate}.txt
├── css/{beginner,intermediate}.txt
├── csharp/{beginner,intermediate}.txt
├── python/{beginner,intermediate}.txt
├── react/{beginner,intermediate}.txt
├── spring/{beginner,intermediate}.txt
├── azure/{beginner,intermediate}.txt
└── docker/{beginner,intermediate}.txt
```

## Adding Your Own Tips

```bash
# Add to any file
echo "Use @Async to execute methods asynchronously in separate thread" \
  >> ~/dotfiles/tips/spring/intermediate.txt

# Tips will appear in daily rotation automatically
```
